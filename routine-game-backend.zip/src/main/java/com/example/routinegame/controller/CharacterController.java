package com.example.routinegame.controller;

import com.example.routinegame.service.CharacterService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/character")
@RequiredArgsConstructor
public class CharacterController {

    private final CharacterService characterService;

    @PostMapping("/{userId}/result")
    public void applyRoutineResult(@PathVariable Long userId, @RequestParam boolean isSuccess) {
        characterService.applyRoutineResult(userId, isSuccess);
    }
}

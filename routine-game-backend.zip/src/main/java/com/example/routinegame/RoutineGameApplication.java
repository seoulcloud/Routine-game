package com.example.routinegame;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoutineGameApplication {
    public static void main(String[] args) {
        SpringApplication.run(RoutineGameApplication.class, args);
    }
}
